class MenuModel {
  String icon;
  String title;
  MenuModel({required this.icon, required this.title});
}
