class ScheduledModel {
  String title;
  String date;
  ScheduledModel({required this.title, required this.date});
}
