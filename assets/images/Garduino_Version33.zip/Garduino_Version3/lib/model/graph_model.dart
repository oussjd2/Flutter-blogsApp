class GraphModel {
  final double x;
  final double y;

  GraphModel({required this.x, required this.y});
}
