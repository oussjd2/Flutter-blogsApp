package com.dashboard.flutter.app.garduino_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
